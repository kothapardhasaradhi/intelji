
package com.mgic.ct.claims.processing.service.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "addressLineText",
    "addressLine2Text",
    "cityName",
    "stateCode",
    "postalCode"
})

public class Address implements Serializable {

    private static final long serialVersionUID = 5256024739234852659L;

    @JsonProperty("addressLineText")
    private String addressLineText;
    @JsonProperty("addressLine2Text")
    private String addressLine2Text;
    @JsonProperty("cityName")
    private String cityName;
    @JsonProperty("stateCode")
    private String stateCode;
    @JsonProperty("postalCode")
    private String postalCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("addressLineText")
    public String getAddressLineText() {
        return addressLineText;
    }

    @JsonProperty("addressLineText")
    public void setAddressLineText(String addressLineText) {
        this.addressLineText = addressLineText;
    }

    @JsonProperty("addressLine2Text")
    public String getAddressLine2Text() {
        return addressLine2Text;
    }

    @JsonProperty("addressLine2Text")
    public void setAddressLine2Text(String addressLine2Text) {
        this.addressLine2Text = addressLine2Text;
    }

    @JsonProperty("cityName")
    public String getCityName() {
        return cityName;
    }

    @JsonProperty("cityName")
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    @JsonProperty("stateCode")
    public String getStateCode() {
        return stateCode;
    }

    @JsonProperty("stateCode")
    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    @JsonProperty("postalCode")
    public String getPostalCode() {
        return postalCode;
    }

    @JsonProperty("postalCode")
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
