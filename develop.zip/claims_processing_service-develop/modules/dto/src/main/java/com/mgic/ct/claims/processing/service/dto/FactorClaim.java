
package com.mgic.ct.claims.processing.service.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "certificateIdentifier",
    "parties",
    "claimSubmissionType",
    "claimSubmimissonDate",
    "fileSubmimissonDate",
    "unpaidPrincipalBalanceAtDefaultAmount",
    "originalPrincipalBalanceAmount",
    "allowedUnpaidPrincipalBalanceAmount",
    "claimInterestAmount",
    "property",
    "titleTransferType",
    "titleTransferDate",
    "lastPaidInstallmentDate",
    "lastPaidInstallmentNoteRate",
    "titleTransferValueAmount",
    "lastPaidInstallmentToLiquidationActualDays",
    "forclosureStateTimelineDays",
    "allowableDelaysDays",
    "totalTimelineDays",
    "allowedDays",
    "fixedFactorPercent",
    "expectedClaimFixedExpenseAmount",
    "variableFactorPercent",
    "expectedClaimVariableExpenseAmount",
    "saleProceedsAmount",
    "saleClosingDate",
    "grossSaleProceedsAmount",
    "netSalesProceedsAmount",
    "geoCluster",
    "expectedClaimPayment",
    "miCoveragePercent",
    "claimForLossAmount",
    "delinquentInterestUnpaidPrincipalBalanceAmount",
    "forgivenPrincipalAmount"
})

public class FactorClaim implements Serializable {

    private static final long serialVersionUID = -4089565647090285598L;

    @JsonProperty("certificateIdentifier")
    private BigInteger certificateIdentifier;
    @JsonProperty("parties")
    private Parties parties;
    @JsonProperty("claimSubmissionType")
    private String claimSubmissionType;
    @JsonProperty("claimSubmimissonDate")
    private Date claimSubmimissonDate;
    @JsonProperty("fileSubmimissonDate")
    private Date fileSubmimissonDate;
    @JsonProperty("unpaidPrincipalBalanceAtDefaultAmount")
    private Double unpaidPrincipalBalanceAtDefaultAmount;
    @JsonProperty("originalPrincipalBalanceAmount")
    private Double originalPrincipalBalanceAmount;
    @JsonProperty("allowedUnpaidPrincipalBalanceAmount")
    private Double allowedUnpaidPrincipalBalanceAmount;
    @JsonProperty("claimInterestAmount")
    private Double claimInterestAmount;
    @JsonProperty("property")
    private Property property;
    @JsonProperty("titleTransferType")
    private String titleTransferType;
    @JsonProperty("titleTransferDate")
    private Date titleTransferDate;
    @JsonProperty("lastPaidInstallmentDate")
    private Date lastPaidInstallmentDate;
    @JsonProperty("lastPaidInstallmentNoteRate")
    private Double lastPaidInstallmentNoteRate;
    @JsonProperty("titleTransferValueAmount")
    private Double titleTransferValueAmount;
    @JsonProperty("lastPaidInstallmentToLiquidationActualDays")
    private Integer lastPaidInstallmentToLiquidationActualDays;
    @JsonProperty("forclosureStateTimelineDays")
    private Integer forclosureStateTimelineDays;
    @JsonProperty("allowableDelaysDays")
    private Integer allowableDelaysDays;
    @JsonProperty("totalTimelineDays")
    private Integer totalTimelineDays;
    @JsonProperty("allowedDays")
    private Integer allowedDays;
    @JsonProperty("fixedFactorPercent")
    private Double fixedFactorPercent;
    @JsonProperty("expectedClaimFixedExpenseAmount")
    private Double expectedClaimFixedExpenseAmount;
    @JsonProperty("variableFactorPercent")
    private Double variableFactorPercent;
    @JsonProperty("expectedClaimVariableExpenseAmount")
    private Double expectedClaimVariableExpenseAmount;
    @JsonProperty("saleProceedsAmount")
    private Double saleProceedsAmount;
    @JsonProperty("saleClosingDate")
    private Date saleClosingDate;
    @JsonProperty("grossSaleProceedsAmount")
    private Double grossSaleProceedsAmount;
    @JsonProperty("netSalesProceedsAmount")
    private Double netSalesProceedsAmount;
    @JsonProperty("geoCluster")
    private Integer geoCluster;
    @JsonProperty("expectedClaimPayment")
    private Double expectedClaimPayment;
    @JsonProperty("miCoveragePercent")
    private Double miCoveragePercent;
    @JsonProperty("claimForLossAmount")
    private Double claimForLossAmount;
    @JsonProperty("delinquentInterestUnpaidPrincipalBalanceAmount")
    private Double delinquentInterestUnpaidPrincipalBalanceAmount;
    @JsonProperty("forgivenPrincipalAmount")
    private Double forgivenPrincipalAmount;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("certificateIdentifier")
    public BigInteger getCertificateIdentifier() {
        return certificateIdentifier;
    }

    @JsonProperty("certificateIdentifier")
    public void setCertificateIdentifier(BigInteger certificateIdentifier) {
        this.certificateIdentifier = certificateIdentifier;
    }

    @JsonProperty("parties")
    public Parties getParties() {
        return parties;
    }

    @JsonProperty("parties")
    public void setParties(Parties parties) {
        this.parties = parties;
    }

    @JsonProperty("claimSubmissionType")
    public String getClaimSubmissionType() {
        return claimSubmissionType;
    }

    @JsonProperty("claimSubmissionType")
    public void setClaimSubmissionType(String claimSubmissionType) {
        this.claimSubmissionType = claimSubmissionType;
    }

    @JsonProperty("claimSubmimissonDate")
    public Date getClaimSubmimissonDate() {
        return claimSubmimissonDate;
    }

    @JsonProperty("claimSubmimissonDate")
    public void setClaimSubmimissonDate(Date claimSubmimissonDate) {
        this.claimSubmimissonDate = claimSubmimissonDate;
    }

    @JsonProperty("fileSubmimissonDate")
    public Date getFileSubmimissonDate() {
        return fileSubmimissonDate;
    }

    @JsonProperty("fileSubmimissonDate")
    public void setFileSubmimissonDate(Date fileSubmimissonDate) {
        this.fileSubmimissonDate = fileSubmimissonDate;
    }

    @JsonProperty("unpaidPrincipalBalanceAtDefaultAmount")
    public Double getUnpaidPrincipalBalanceAtDefaultAmount() {
        return unpaidPrincipalBalanceAtDefaultAmount;
    }

    @JsonProperty("unpaidPrincipalBalanceAtDefaultAmount")
    public void setUnpaidPrincipalBalanceAtDefaultAmount(Double unpaidPrincipalBalanceAtDefaultAmount) {
        this.unpaidPrincipalBalanceAtDefaultAmount = unpaidPrincipalBalanceAtDefaultAmount;
    }

    @JsonProperty("originalPrincipalBalanceAmount")
    public Double getOriginalPrincipalBalanceAmount() {
        return originalPrincipalBalanceAmount;
    }

    @JsonProperty("originalPrincipalBalanceAmount")
    public void setOriginalPrincipalBalanceAmount(Double originalPrincipalBalanceAmount) {
        this.originalPrincipalBalanceAmount = originalPrincipalBalanceAmount;
    }

    @JsonProperty("allowedUnpaidPrincipalBalanceAmount")
    public Double getAllowedUnpaidPrincipalBalanceAmount() {
        return allowedUnpaidPrincipalBalanceAmount;
    }

    @JsonProperty("allowedUnpaidPrincipalBalanceAmount")
    public void setAllowedUnpaidPrincipalBalanceAmount(Double allowedUnpaidPrincipalBalanceAmount) {
        this.allowedUnpaidPrincipalBalanceAmount = allowedUnpaidPrincipalBalanceAmount;
    }

    @JsonProperty("claimInterestAmount")
    public Double getClaimInterestAmount() {
        return claimInterestAmount;
    }

    @JsonProperty("claimInterestAmount")
    public void setClaimInterestAmount(Double claimInterestAmount) {
        this.claimInterestAmount = claimInterestAmount;
    }

    @JsonProperty("property")
    public Property getProperty() {
        return property;
    }

    @JsonProperty("property")
    public void setProperty(Property property) {
        this.property = property;
    }

    @JsonProperty("titleTransferType")
    public String getTitleTransferType() {
        return titleTransferType;
    }

    @JsonProperty("titleTransferType")
    public void setTitleTransferType(String titleTransferType) {
        this.titleTransferType = titleTransferType;
    }

    @JsonProperty("titleTransferDate")
    public Date getTitleTransferDate() {
        return titleTransferDate;
    }

    @JsonProperty("titleTransferDate")
    public void setTitleTransferDate(Date titleTransferDate) {
        this.titleTransferDate = titleTransferDate;
    }

    @JsonProperty("lastPaidInstallmentDate")
    public Date getLastPaidInstallmentDate() {
        return lastPaidInstallmentDate;
    }

    @JsonProperty("lastPaidInstallmentDate")
    public void setLastPaidInstallmentDate(Date lastPaidInstallmentDate) {
        this.lastPaidInstallmentDate = lastPaidInstallmentDate;
    }

    @JsonProperty("lastPaidInstallmentNoteRate")
    public Double getLastPaidInstallmentNoteRate() {
        return lastPaidInstallmentNoteRate;
    }

    @JsonProperty("lastPaidInstallmentNoteRate")
    public void setLastPaidInstallmentNoteRate(Double lastPaidInstallmentNoteRate) {
        this.lastPaidInstallmentNoteRate = lastPaidInstallmentNoteRate;
    }

    @JsonProperty("titleTransferValueAmount")
    public Double getTitleTransferValueAmount() {
        return titleTransferValueAmount;
    }

    @JsonProperty("titleTransferValueAmount")
    public void setTitleTransferValueAmount(Double titleTransferValueAmount) {
        this.titleTransferValueAmount = titleTransferValueAmount;
    }

    @JsonProperty("lastPaidInstallmentToLiquidationActualDays")
    public Integer getLastPaidInstallmentToLiquidationActualDays() {
        return lastPaidInstallmentToLiquidationActualDays;
    }

    @JsonProperty("lastPaidInstallmentToLiquidationActualDays")
    public void setLastPaidInstallmentToLiquidationActualDays(Integer lastPaidInstallmentToLiquidationActualDays) {
        this.lastPaidInstallmentToLiquidationActualDays = lastPaidInstallmentToLiquidationActualDays;
    }

    @JsonProperty("forclosureStateTimelineDays")
    public Integer getForclosureStateTimelineDays() {
        return forclosureStateTimelineDays;
    }

    @JsonProperty("forclosureStateTimelineDays")
    public void setForclosureStateTimelineDays(Integer forclosureStateTimelineDays) {
        this.forclosureStateTimelineDays = forclosureStateTimelineDays;
    }

    @JsonProperty("allowableDelaysDays")
    public Integer getAllowableDelaysDays() {
        return allowableDelaysDays;
    }

    @JsonProperty("allowableDelaysDays")
    public void setAllowableDelaysDays(Integer allowableDelaysDays) {
        this.allowableDelaysDays = allowableDelaysDays;
    }

    @JsonProperty("totalTimelineDays")
    public Integer getTotalTimelineDays() {
        return totalTimelineDays;
    }

    @JsonProperty("totalTimelineDays")
    public void setTotalTimelineDays(Integer totalTimelineDays) {
        this.totalTimelineDays = totalTimelineDays;
    }

    @JsonProperty("allowedDays")
    public Integer getAllowedDays() {
        return allowedDays;
    }

    @JsonProperty("allowedDays")
    public void setAllowedDays(Integer allowedDays) {
        this.allowedDays = allowedDays;
    }

    @JsonProperty("fixedFactorPercent")
    public Double getFixedFactorPercent() {
        return fixedFactorPercent;
    }

    @JsonProperty("fixedFactorPercent")
    public void setFixedFactorPercent(Double fixedFactorPercent) {
        this.fixedFactorPercent = fixedFactorPercent;
    }

    @JsonProperty("expectedClaimFixedExpenseAmount")
    public Double getExpectedClaimFixedExpenseAmount() {
        return expectedClaimFixedExpenseAmount;
    }

    @JsonProperty("expectedClaimFixedExpenseAmount")
    public void setExpectedClaimFixedExpenseAmount(Double expectedClaimFixedExpenseAmount) {
        this.expectedClaimFixedExpenseAmount = expectedClaimFixedExpenseAmount;
    }

    @JsonProperty("variableFactorPercent")
    public Double getVariableFactorPercent() {
        return variableFactorPercent;
    }

    @JsonProperty("variableFactorPercent")
    public void setVariableFactorPercent(Double variableFactorPercent) {
        this.variableFactorPercent = variableFactorPercent;
    }

    @JsonProperty("expectedClaimVariableExpenseAmount")
    public Double getExpectedClaimVariableExpenseAmount() {
        return expectedClaimVariableExpenseAmount;
    }

    @JsonProperty("expectedClaimVariableExpenseAmount")
    public void setExpectedClaimVariableExpenseAmount(Double expectedClaimVariableExpenseAmount) {
        this.expectedClaimVariableExpenseAmount = expectedClaimVariableExpenseAmount;
    }

    @JsonProperty("saleProceedsAmount")
    public Double getSaleProceedsAmount() {
        return saleProceedsAmount;
    }

    @JsonProperty("saleProceedsAmount")
    public void setSaleProceedsAmount(Double saleProceedsAmount) {
        this.saleProceedsAmount = saleProceedsAmount;
    }

    @JsonProperty("saleClosingDate")
    public Date getSaleClosingDate() {
        return saleClosingDate;
    }

    @JsonProperty("saleClosingDate")
    public void setSaleClosingDate(Date saleClosingDate) {
        this.saleClosingDate = saleClosingDate;
    }

    @JsonProperty("grossSaleProceedsAmount")
    public Double getGrossSaleProceedsAmount() {
        return grossSaleProceedsAmount;
    }

    @JsonProperty("grossSaleProceedsAmount")
    public void setGrossSaleProceedsAmount(Double grossSaleProceedsAmount) {
        this.grossSaleProceedsAmount = grossSaleProceedsAmount;
    }

    @JsonProperty("netSalesProceedsAmount")
    public Double getNetSalesProceedsAmount() {
        return netSalesProceedsAmount;
    }

    @JsonProperty("netSalesProceedsAmount")
    public void setNetSalesProceedsAmount(Double netSalesProceedsAmount) {
        this.netSalesProceedsAmount = netSalesProceedsAmount;
    }

    @JsonProperty("geoCluster")
    public Integer getGeoCluster() {
        return geoCluster;
    }

    @JsonProperty("geoCluster")
    public void setGeoCluster(Integer geoCluster) {
        this.geoCluster = geoCluster;
    }

    @JsonProperty("expectedClaimPayment")
    public Double getExpectedClaimPayment() {
        return expectedClaimPayment;
    }

    @JsonProperty("expectedClaimPayment")
    public void setExpectedClaimPayment(Double expectedClaimPayment) {
        this.expectedClaimPayment = expectedClaimPayment;
    }

    @JsonProperty("miCoveragePercent")
    public Double getMiCoveragePercent() {
        return miCoveragePercent;
    }

    @JsonProperty("miCoveragePercent")
    public void setMiCoveragePercent(Double miCoveragePercent) {
        this.miCoveragePercent = miCoveragePercent;
    }

    @JsonProperty("claimForLossAmount")
    public Double getClaimForLossAmount() {
        return claimForLossAmount;
    }

    @JsonProperty("claimForLossAmount")
    public void setClaimForLossAmount(Double claimForLossAmount) {
        this.claimForLossAmount = claimForLossAmount;
    }

    @JsonProperty("delinquentInterestUnpaidPrincipalBalanceAmount")
    public Double getDelinquentInterestUnpaidPrincipalBalanceAmount() {
        return delinquentInterestUnpaidPrincipalBalanceAmount;
    }

    @JsonProperty("delinquentInterestUnpaidPrincipalBalanceAmount")
    public void setDelinquentInterestUnpaidPrincipalBalanceAmount(Double delinquentInterestUnpaidPrincipalBalanceAmount) {
        this.delinquentInterestUnpaidPrincipalBalanceAmount = delinquentInterestUnpaidPrincipalBalanceAmount;
    }

    @JsonProperty("forgivenPrincipalAmount")
    public Double getForgivenPrincipalAmount() {
        return forgivenPrincipalAmount;
    }

    @JsonProperty("forgivenPrincipalAmount")
    public void setForgivenPrincipalAmount(Double forgivenPrincipalAmount) {
        this.forgivenPrincipalAmount = forgivenPrincipalAmount;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
