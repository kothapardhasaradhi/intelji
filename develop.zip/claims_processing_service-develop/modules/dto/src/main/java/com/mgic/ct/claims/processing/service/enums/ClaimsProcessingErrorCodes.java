package com.mgic.ct.claims.processing.service.enums;

import com.mgic.infra.lib.exception.ErrorCode;

public enum ClaimsProcessingErrorCodes implements ErrorCode
{
   FACTOR_CLAIM_VALIDATION_FAILED("FACTOR_CLAIM_VALIDATION_FAILED");


   private final String errorCode;

   ClaimsProcessingErrorCodes (String errorCode)
   {
      this.errorCode = errorCode;
   }

   public String getErrorCode ()
   {
      return errorCode;
   }
}