
package com.mgic.ct.claims.processing.service.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "transactionId",
    "clientIdentifier",
    "receivedDate",
    "sentDate",
    "version"
})

public class Metadata implements Serializable {

    private static final long serialVersionUID = -8103999196649585543L;

    @JsonProperty("transactionId")
    private BigInteger transactionId;
    @JsonProperty("clientIdentifier")
    private String clientIdentifier;
    @JsonProperty("receivedDate")
    private Date receivedDate;
    @JsonProperty("sentDate")
    private String sentDate;
    @JsonProperty("version")
    private String version;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("transactionId")
    public BigInteger getTransactionId() {
        return transactionId;
    }

    @JsonProperty("transactionId")
    public void setTransactionId(BigInteger transactionId) {
        this.transactionId = transactionId;
    }

    @JsonProperty("clientIdentifier")
    public String getClientIdentifier() {
        return clientIdentifier;
    }

    @JsonProperty("clientIdentifier")
    public void setClientIdentifier(String clientIdentifier) {
        this.clientIdentifier = clientIdentifier;
    }

    @JsonProperty("receivedDate")
    public Date getReceivedDate() {
        return receivedDate;
    }

    @JsonProperty("receivedDate")
    public void setReceivedDate(Date receivedDate) {
        this.receivedDate = receivedDate;
    }

    @JsonProperty("sentDate")
    public String getSentDate() {
        return sentDate;
    }

    @JsonProperty("sentDate")
    public void setSentDate(String sentDate) {
        this.sentDate = sentDate;
    }

    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
