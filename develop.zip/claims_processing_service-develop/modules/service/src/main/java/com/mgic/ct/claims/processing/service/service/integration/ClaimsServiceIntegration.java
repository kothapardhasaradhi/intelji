package com.mgic.ct.claims.processing.service.service.integration;


public interface ClaimsServiceIntegration
{
   Boolean validateCertificate (String certificateIdentifier) ;
}
