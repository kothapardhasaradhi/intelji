package com.mgic.ct.claims.processing.service.service.adapter;

import com.mgic.ct.claims.processing.service.dto.FactorClaimDTO;
import com.mgic.ct.claims.processing.service.service.integration.ClaimsServiceIntegration;
import com.mgic.ct.claims.processing.service.service.integration.WorkFlowBaseIntegration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ClaimsProcessorAdapter
{

   private static final Logger LOGGER = LoggerFactory.getLogger(ClaimsProcessorAdapter.class);

   @Autowired
   WorkFlowBaseIntegration workFlowBaseIntegration;
   @Autowired
   ClaimsServiceIntegration claimsServiceIntegration;

   public void startWorkflow (FactorClaimDTO factorClaimDTO)
   {
      workFlowBaseIntegration.startWorkflowProcessing(factorClaimDTO);
   }

   public Boolean validateCertificate (String certificateIdentifier)
   {
      return claimsServiceIntegration.validateCertificate(certificateIdentifier);
   }
}
