package com.mgic.ct.claims.processing.service.service.integration;

import com.mgic.ct.claims.processing.service.dto.FactorClaimDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class WorkFlowBaseIntegrationImpl implements WorkFlowBaseIntegration
{

    private static final Logger LOGGER = LoggerFactory.getLogger(WorkFlowBaseIntegrationImpl.class);

    @Autowired
    private WebClient.Builder webClientBuilder;

    @Value("${workflow.base.url}")
    private String workflowBaseUrl;

    @Value("${workflow.service.start.process.uri}")
    private String workflowStartUri;

    private WebClient getCaseManagerIntegrationWebClient() {
        LOGGER.info("Integrating with MQ service with Base Url...{}",workflowBaseUrl);
        return webClientBuilder.baseUrl(workflowBaseUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_XML_VALUE).build();
    }

    @Override
    public void startWorkflowProcessing(FactorClaimDTO factorClaimDTO) {

        getCaseManagerIntegrationWebClient().post().uri(workflowStartUri)
                .bodyValue(factorClaimDTO);
    }


}
