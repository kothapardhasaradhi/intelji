package com.mgic.ct.claims.processing.service.service.integration;

import com.mgic.ct.claims.processing.service.dto.FactorClaimDTO;

public interface WorkFlowBaseIntegration
{
    void startWorkflowProcessing(FactorClaimDTO factorClaimDTO);
}
