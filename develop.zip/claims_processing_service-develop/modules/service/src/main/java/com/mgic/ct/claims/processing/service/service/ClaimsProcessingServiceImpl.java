package com.mgic.ct.claims.processing.service.service;

import com.mgic.ct.claims.processing.service.dto.FactorClaimDTO;

import com.mgic.ct.claims.processing.service.enums.ClaimsProcessingErrorCodes;
import com.mgic.ct.claims.processing.service.service.adapter.ClaimsProcessorAdapter;
import com.mgic.ct.claims.processing.service.service.validation.ClaimsProcessingValidator;
import com.mgic.infra.lib.exception.CoreIntegrationRuntimeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClaimsProcessingServiceImpl implements ClaimsProcessingService
{
   private static final Logger LOGGER = LoggerFactory.getLogger(ClaimsProcessingServiceImpl.class);

   @Autowired
   ClaimsProcessorAdapter claimsProcessorAdapter;
   @Autowired
   ClaimsProcessingValidator claimsProcessingValidator;

   @Override
   public Boolean validateCertificate (FactorClaimDTO factorClaimDTO)
      throws CoreIntegrationRuntimeException
   {
      LOGGER.info("FactorClaimDTO : {}", factorClaimDTO);
      if (!claimsProcessingValidator.validateCertificate(factorClaimDTO)) {
         throw new CoreIntegrationRuntimeException(ClaimsProcessingErrorCodes.FACTOR_CLAIM_VALIDATION_FAILED, "FACTOR_CLAIM_VALIDATION_FAILED", null);
      }
      return Boolean.TRUE;
   }

   @Override
   public void startWorkflow (FactorClaimDTO factorClaimDTO)
   {
      LOGGER.info("FactorClaimDTO : {}", factorClaimDTO);
      claimsProcessorAdapter.startWorkflow(factorClaimDTO);
   }
}
