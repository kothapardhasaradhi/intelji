package com.mgic.ct.claims.processing.service.service.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class ClaimsServiceIntegrationImpl implements ClaimsServiceIntegration
{
   private static final Logger LOGGER = LoggerFactory.getLogger(ClaimsServiceIntegrationImpl.class);

   @Autowired
   @Qualifier("claimsServiceWebClient")
   private WebClient claimsServiceWebClient;

   @Value("${claims.service.validate.certificate.uri}")
   private String claimsServiceValidateCertificateUri;

   ///validateFnmaCertificate/{certificateIdentifier}
   @Override
   public Boolean validateCertificate (String certificateIdentifier)
   {
      Boolean isValidCertificate = Boolean.FALSE;
      LOGGER.info("validateCertificate - certificate number: {}", certificateIdentifier);
      try {
         isValidCertificate = claimsServiceWebClient.get().uri(claimsServiceValidateCertificateUri + "/" + certificateIdentifier).retrieve().bodyToMono(Boolean.class).block();
      } catch (Exception e) {
         LOGGER.error("Exception while retrieving data from claims service ", e);
      }
      return isValidCertificate;
   }
}
