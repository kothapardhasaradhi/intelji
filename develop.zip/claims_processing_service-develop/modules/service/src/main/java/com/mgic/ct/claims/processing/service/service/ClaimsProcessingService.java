package com.mgic.ct.claims.processing.service.service;

import com.mgic.ct.claims.processing.service.dto.FactorClaimDTO;
import com.mgic.infra.lib.exception.CoreIntegrationRuntimeException;

public interface ClaimsProcessingService
{

   Boolean validateCertificate (FactorClaimDTO factorClaimDTO) throws CoreIntegrationRuntimeException;

   void startWorkflow (FactorClaimDTO loanHistoryDto);
}
