package com.mgic.ct.claims.processing.service.interfaces.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionHandlers
{
   private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandlers.class);

//   @ResponseStatus(HttpStatus.BAD_REQUEST)
//   @ExceptionHandler(MethodArgumentNotValidException.class)
//   public void handleValidationExceptions (MethodArgumentNotValidException ex)
//   {
//      LOGGER.info("handleValidationExceptions" + ex.toString());
//      Map<String, String> errors = new HashMap<>();
//      ex.getBindingResult().getAllErrors().forEach((error) -> {
//         String fieldName = ((FieldError) error).getField();
//         String errorMessage = error.getDefaultMessage();
//         errors.put(fieldName, errorMessage);
//      });
//      throw new CoreIntegrationRuntimeException(ClaimsProcessingErrorCodes.FACTOR_CLAIM_VALIDATION_FAILED, errors.toString(), ex);
//   }
}
