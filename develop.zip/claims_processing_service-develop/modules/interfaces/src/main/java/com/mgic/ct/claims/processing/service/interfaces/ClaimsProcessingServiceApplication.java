package com.mgic.ct.claims.processing.service.interfaces;

import com.mgic.ct.claims.processing.service.interfaces.config.ApiDocConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableConfigurationProperties(ApiDocConfig.class)
@ComponentScan({"com.mgic.ct.claims.processing.service", "com.mgic.ct.claims.processing.service.repository", "com.mgic.infra.lib.service.starter"})
public class ClaimsProcessingServiceApplication
{

   private static final Logger logger = LoggerFactory.getLogger(ClaimsProcessingServiceApplication.class);

   public static void main (String[] args)
   {
      SpringApplication.run(ClaimsProcessingServiceApplication.class, args);
   }
}