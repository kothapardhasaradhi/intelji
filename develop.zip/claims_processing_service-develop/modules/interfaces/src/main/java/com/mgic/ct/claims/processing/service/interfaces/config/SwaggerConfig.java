package com.mgic.ct.claims.processing.service.interfaces.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Contact;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.function.Predicate;


/**
 * Configuration used by springfox maven plugin to scan and generate swagger docs
 */
@Configuration
public class SwaggerConfig {
    
    @Autowired
    private ApiDocConfig apiDocConfig;

    @Bean
    public Docket apiDocket() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.any())
                .paths(Predicate.not(PathSelectors.regex(apiDocConfig.getEndpointExclusionList())))
                .build()
                .securitySchemes(Collections.singletonList(apiKey()))
                .securityContexts(Collections.singletonList(securityContext()))
                .useDefaultResponseMessages(apiDocConfig.isUseDefaultResponseMessage())
                .enableUrlTemplating(apiDocConfig.isEnableUrlTemplate())
                .consumes(new HashSet<>(Arrays.asList(apiDocConfig.getContentType())))
                .produces(new HashSet<>(Arrays.asList(apiDocConfig.getContentType())))
                .apiInfo(metaData());
    }

    private ApiKey apiKey() {
        return new ApiKey(apiDocConfig.getApiKeyName(), apiDocConfig.getApiKeyKeyName(), apiDocConfig.getApiKeyPassAs());
    }

    private SecurityContext securityContext() {
        return SecurityContext.builder().securityReferences(defaultAuth()).build();
    }

    private List<SecurityReference> defaultAuth() {
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = new AuthorizationScope("global", "accessEverything");
        return Collections.singletonList(new SecurityReference(apiDocConfig.getApiKeyName(), authorizationScopes));
    }

    private ApiInfo metaData() {
        return new ApiInfo(
                apiDocConfig.getTitle(),
                apiDocConfig.getDescription(),
                apiDocConfig.getVersion(),
                apiDocConfig.getTermsOfServiceUrl(),
                new Contact(apiDocConfig.getContactName(), apiDocConfig.getContactUrl(), apiDocConfig.getContactEmail()),
                apiDocConfig.getLicense(),
                apiDocConfig.getLicenseUrl(),
                Collections.emptyList());
    }   
}