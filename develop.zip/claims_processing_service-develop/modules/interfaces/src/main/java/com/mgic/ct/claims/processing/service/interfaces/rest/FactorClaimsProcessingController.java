package com.mgic.ct.claims.processing.service.interfaces.rest;

import javax.validation.Valid;

import com.mgic.ct.claims.processing.service.dto.FactorClaimDTO;
import com.mgic.ct.claims.processing.service.service.ClaimsProcessingService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import com.mgic.infra.lib.exception.CoreIntegrationRuntimeException;

@RestController
@RequestMapping("/factorclaims")
public class FactorClaimsProcessingController
{

   @Autowired
   ClaimsProcessingService claimsProcessingService;

   /**
    * To validate certificate
    * @param factorClaimDTO
    * @return
    * @throws CoreIntegrationRuntimeException
    */
   @PostMapping(value = "/validateCertificate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
   @ResponseStatus(HttpStatus.OK)
   public Boolean validateCertificate (@Valid @RequestBody FactorClaimDTO factorClaimDTO)
      throws CoreIntegrationRuntimeException
   {
      return claimsProcessingService.validateCertificate(factorClaimDTO);
   }

   /**
    * To validate JSON , Parse and call workflow service to start the workflow
    * @param inputJson
    * @return
    * @throws CoreIntegrationRuntimeException
    */
   @PostMapping(value = "/validateFactorClaim", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
   @ResponseStatus(HttpStatus.OK)
   public Boolean validateFactorClaim (@Valid @RequestBody String inputJson)
      throws CoreIntegrationRuntimeException
   {
      Boolean isValidFactorClaim = Boolean.FALSE;
   /* TODO :
      String json format
       parse json , validate json fields according to xls
      populate dto from json
      call workflow service to start workflow
    */
      return isValidFactorClaim;
   }

   //   @PostMapping(value = "/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
   //   @ResponseStatus(HttpStatus.OK)
   //   public void processB2Bmessage (@RequestBody FactorClaimDTO factorClaimDTO) // agrgument -> String
   //   {
   //      //Call workflow service from here only with Dto
   //      //This will an asynchronous call.
   //      claimsProcessingService.startWorkflow(factorClaimDTO);
   //   }

   // TODO : write api to save Factor claim data and call claims services
   // /saveFactorClaim

   //   @GetMapping(value = "/runReconciliationRule/{certificateIdentifier}", produces = MediaType.APPLICATION_JSON_VALUE)
   //   private ResponseEntity<FactorClaimReconcilationResponse> validateFactorClaim(@NotEmpty @PathVariable("certificateIdentifier") String certificateIdentifier)
   //      throws CoreIntegrationValidationException, ClaimServiceException
   //   {
   //      LOGGER.info("received factor claim reconcilation rule request: {}", certificateIdentifier);
   //      return ResponseEntity.ok(factorClaimReconcilationService.runReconciliationRules(certificateIdentifier));
   //   }

   //   @GetMapping(value = "/compareFactorClaimData/{certificateIdentifier}", produces = MediaType.APPLICATION_JSON_VALUE)
   //   @ResponseStatus(HttpStatus.OK)
   //   private Boolean compareFactorClaimAndFnma (@NotEmpty @PathVariable("certificateIdentifier") String certificateIdentifier)
   //      throws CoreIntegrationRuntimeException
   //   {
   //      return claimDataComparisonService.compareFactorClaimAndFnma(certificateIdentifier);
   //   }

   //   @GetMapping(value = "/factorClaimCalculation/{certificateNumber}/{guid}", produces = MediaType.APPLICATION_JSON_VALUE)
   //   @ResponseStatus(HttpStatus.OK)
   //   private Boolean isValidDecisionResponse (@NotEmpty @PathVariable("certificateIdentifier") String certificateIdentifier,
   //                                            @NotEmpty @PathVariable("guid") String guid)
   //      throws CoreIntegrationRuntimeException
   //   {
   //      return decisionIntegrationService.isValidDecisionResponse(certificateIdentifier, guid);
   //   }

   //   @ResponseStatus(HttpStatus.BAD_REQUEST)
   //   @ExceptionHandler(MethodArgumentNotValidException.class)
   //   public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
   //      Map<String, String> errors = new HashMap<>();
   //      ex.getBindingResult().getAllErrors().forEach((error) -> {
   //         String fieldName = ((FieldError) error).getField();
   //         String errorMessage = error.getDefaultMessage();
   //         errors.put(fieldName, errorMessage);
   //      });
   //      return errors;
   //   }
}
